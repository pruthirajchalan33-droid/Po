import React, { useState } from 'react';
import LanternRail from './components/LanternRail';
import Header from './components/Header';
import Hero from './components/Hero';
import MenuSection from './components/MenuSection';
import AmbienceGallery from './components/AmbienceGallery';
import ReservationSection from './components/ReservationSection';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import { CartItem, MenuItem } from './types';

export default function App() {
  const [cart, setCart] = useState<{ [key: string]: CartItem }>({});
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Add Item or increase quantity
  const handleAddToCart = (item: MenuItem, category: string) => {
    const key = `${category}|||${item.name}`;
    setCart((prevCart) => {
      const existing = prevCart[key];
      if (existing) {
        return {
          ...prevCart,
          [key]: { ...existing, quantity: existing.quantity + 1 },
        };
      } else {
        return {
          ...prevCart,
          [key]: { ...item, category, quantity: 1 },
        };
      }
    });
  };

  // Decrease quantity or remove if it hits 0
  const handleDecreaseInCart = (itemName: string, category: string) => {
    const key = `${category}|||${itemName}`;
    setCart((prevCart) => {
      const existing = prevCart[key];
      if (!existing) return prevCart;

      if (existing.quantity <= 1) {
        const nextCart = { ...prevCart };
        delete nextCart[key];
        return nextCart;
      } else {
        return {
          ...prevCart,
          [key]: { ...existing, quantity: existing.quantity - 1 },
        };
      }
    });
  };

  // Remove completely
  const handleRemoveFromCart = (key: string) => {
    setCart((prevCart) => {
      const nextCart = { ...prevCart };
      delete nextCart[key];
      return nextCart;
    });
  };

  // Header explore trigger scrolls smoothly to menu
  const handleScrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Total items inside the cart
  const cartCount = (Object.values(cart) as CartItem[]).reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#F6F0E2] text-[#241F19] selection:bg-[#C4703C]/30 selection:text-[#1F3B2E] font-sans antialiased overflow-x-hidden">
      {/* 1. Hanging Twinkling Lantern Rail */}
      <LanternRail />

      {/* 2. Interactive Floating Header */}
      <Header cartCount={cartCount} onCartClick={() => setIsCartOpen(true)} />

      {/* 3. Hero Showcase with Magnolia Interior */}
      <Hero
        onExploreMenu={() => handleScrollToSection('menu')}
        onBookTable={() => handleScrollToSection('reserve')}
      />

      {/* 5. Rich Multi-cuisine Category List Menu & Search */}
      <MenuSection
        cart={cart}
        onAddToCart={handleAddToCart}
        onDecreaseInCart={handleDecreaseInCart}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Decorative leopard border divider strip */}
      <div 
        className="h-6 bg-[#EDE3CE] opacity-50"
        style={{
          backgroundImage: `
            radial-gradient(ellipse 8px 6px at 10% 40%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 7px 5px at 25% 70%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 9px 6px at 40% 30%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 6px 5px at 55% 65%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 8px 6px at 70% 35%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 7px 5px at 85% 60%, #3A2A1D 40%, transparent 42%),
            radial-gradient(ellipse 8px 6px at 95% 30%, #3A2A1D 40%, transparent 42%)
          `,
          backgroundSize: '120px 24px'
        }}
        aria-hidden="true"
      />

      {/* 5.5. Gorgeous Ambience & Gallery Showcase */}
      <AmbienceGallery />

      {/* 6. Dynamic Booking Form */}
      <ReservationSection />

      {/* 7. Footer Contacts & Location */}
      <Footer />

      {/* 8. Fully Animated Sliding Shopping Cart */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onIncreaseQty={(item) => handleAddToCart(item, item.category)}
        onDecreaseQty={handleDecreaseInCart}
        onRemoveItem={handleRemoveFromCart}
      />
    </div>
  );
}
