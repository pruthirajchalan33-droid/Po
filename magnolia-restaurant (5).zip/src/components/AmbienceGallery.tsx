import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight } from 'lucide-react';

const galleryItems = [
  {
    id: 'dining-hall',
    title: 'The Grand Dining Sanctuary',
    subtitle: 'Cozy Atmosphere',
    description: 'Dine under the serene glow of warm hanging lanterns surrounded by hand-painted botanical murals.',
    image: '/src/assets/images/magnolia_dining_hall_1784906390030.jpg',
  },
  {
    id: 'exterior',
    title: 'The Palace Exterior',
    subtitle: 'Magnificent Presence',
    description: 'A striking, majestically lit modern facade that sets the perfect tone for an exquisite evening.',
    image: '/src/assets/images/magnolia_exterior_1784906450447.jpg',
  },
  {
    id: 'luxury-banquet',
    title: 'Royal Crystal Banquet',
    subtitle: 'High-Ceiling Luxury',
    description: 'Our luxurious banquet space featuring dazzling crystal chandeliers and classic design details.',
    image: '/src/assets/images/magnolia_luxury_banquet_1784906412188.jpg',
  },
  {
    id: 'reception',
    title: 'Warm Artisan Reception',
    subtitle: 'Flawless Hospitality',
    description: 'Your premium experience begins with genuine, highly attentive smiles right at our custom reception.',
    image: '/src/assets/images/magnolia_reception_1784906432184.jpg',
  },
];

export default function AmbienceGallery() {
  return (
    <section 
      id="about" 
      className="py-20 sm:py-28 bg-[#112018] text-[#F6F0E2] relative overflow-hidden"
    >
      {/* Decorative ambient background spots */}
      <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-[#C4703C]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#1F3B2E]/55 rounded-full blur-2xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#E7A64C]/15 border border-[#E7A64C]/30 text-[#F2C97D] text-xs font-bold tracking-wider uppercase"
          >
            <Sparkles className="w-3.5 h-3.5" />
            The Magnolia Experience
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight"
          >
            Step Inside Our Palace
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-sm sm:text-base text-[#EDE3CE]/80 leading-relaxed font-normal"
          >
            A perfect union of luxurious design, cozy retreats, and unforgettable architectural elegance tailored for your special celebrations.
          </motion.p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {galleryItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-[#16291F]/50 rounded-2xl overflow-hidden border border-white/5 hover:border-[#E7A64C]/20 transition-all duration-300 shadow-xl flex flex-col"
            >
              {/* Image Container with Zoom effect */}
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 select-none"
                />
                {/* Subtle dark overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#112018]/80 via-transparent to-transparent opacity-60" />
                
                {/* Badge Overlay */}
                <span className="absolute top-4 left-4 bg-[#C4703C] text-white text-[10px] font-extrabold tracking-wider uppercase px-3 py-1 rounded-full shadow-md">
                  {item.subtitle}
                </span>
              </div>

              {/* Text content area */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-3">
                <div className="space-y-2">
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-white group-hover:text-[#F2C97D] transition-colors duration-200">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#EDE3CE]/75 leading-relaxed font-normal">
                    {item.description}
                  </p>
                </div>

                <div className="pt-2 flex items-center gap-1.5 text-xs text-[#E7A64C] font-bold group-hover:translate-x-1 transition-transform duration-200">
                  <span>Explore this Space</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
