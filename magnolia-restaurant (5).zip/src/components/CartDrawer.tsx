import React, { useState } from 'react';
import { X, ShoppingBag, Plus, Minus, Trash2, ArrowRight, User, Phone, Hash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem } from '../types';
import { getFoodEmoji } from '../data/menu';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: { [key: string]: CartItem };
  onIncreaseQty: (item: CartItem) => void;
  onDecreaseQty: (itemName: string, category: string) => void;
  onRemoveItem: (key: string) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onIncreaseQty,
  onDecreaseQty,
  onRemoveItem,
}: CartDrawerProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [dineInNo, setDineInNo] = useState('');
  const [errors, setErrors] = useState<{ name?: boolean; phone?: boolean; dineInNo?: boolean }>({});

  const cartEntries = Object.entries(cart);
  const totalAmount = cartEntries.reduce((sum, [_, item]) => sum + item.price * item.quantity, 0);
  const totalCount = cartEntries.reduce((sum, [_, item]) => sum + item.quantity, 0);
  const gstAmount = Math.round(totalAmount * 0.05);
  const grandTotal = totalAmount + gstAmount;

  const handleWhatsAppCheckout = () => {
    if (cartEntries.length === 0) return;

    // Validation
    const newErrors = {
      name: !name.trim(),
      phone: !phone.trim(),
      dineInNo: !dineInNo.trim(),
    };

    if (newErrors.name || newErrors.phone || newErrors.dineInNo) {
      setErrors(newErrors);
      // Scroll to the error fields
      return;
    }

    setErrors({});

    let message = `Hi Magnolia! 🌸 I'd like to place an order:\n\n`;
    message += `👤 *Customer Name:* ${name.trim()}\n`;
    message += `📞 *Phone Number:* ${phone.trim()}\n`;
    message += `🪑 *Dine In Table No:* ${dineInNo.trim()}\n\n`;
    message += `🍽️ *Order Details:*\n`;
    
    cartEntries.forEach(([_, item]) => {
      const emoji = getFoodEmoji(item.name, item.category);
      message += `${emoji} • ${item.name} x${item.quantity} - ₹${item.price * item.quantity}\n`;
    });
    message += `\nSubtotal: ₹${totalAmount}\n`;
    message += `GST (5%): ₹${gstAmount}\n`;
    message += `🛒 *Grand Total: ₹${grandTotal}*\n\n`;
    message += `Please confirm availability and start preparation. Thank you!`;

    const url = `https://wa.me/917735518976?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay Background */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#241F19] z-50 cursor-pointer"
          />

          {/* Slider Drawer Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 220 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-[#F6F0E2] shadow-2xl z-50 flex flex-col border-l border-[#241F19]/10"
          >
            {/* Header */}
            <div className="p-6 border-b border-[#241F19]/10 flex justify-between items-center bg-[#EDE3CE]">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-[#C4703C]" />
                <h3 className="font-serif text-lg sm:text-xl font-black text-[#1F3B2E]">Your Basket</h3>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-[#241F19]/10 text-[#241F19] transition-colors focus:outline-none cursor-pointer"
                aria-label="Close basket"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cartEntries.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                  <div className="p-4 rounded-full bg-[#EDE3CE] text-[#241F19]/30">
                    <ShoppingBag className="w-12 h-12" />
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-[#1F3B2E] text-lg">Your basket is empty</h4>
                    <p className="text-xs text-[#241F19]/55 max-w-xs mt-1">
                      Browse our categories and add some hot starters, wok noodles or a sizzling brownie.
                    </p>
                  </div>
                </div>
              ) : (
                cartEntries.map(([key, item]) => (
                  <div
                    key={key}
                    className="flex items-start justify-between gap-4 py-4 border-b border-[#241F19]/5 last:border-0"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[#EDE3CE] border border-[#241F19]/8 text-xs shrink-0 select-none shadow-sm">
                          {getFoodEmoji(item.name, item.category)}
                        </span>
                        <span className="inline-block w-3 h-3 rounded border border-emerald-600 bg-emerald-50 flex-shrink-0">
                          <span className="w-1 h-1 rounded-full bg-emerald-600 m-auto block" />
                        </span>
                        <h4 className="font-serif font-bold text-sm text-[#1F3B2E] leading-tight">
                          {item.name}
                        </h4>
                      </div>
                      <span className="inline-block text-[0.62rem] font-bold text-[#241F19]/45 uppercase tracking-wide">
                        {item.category}
                      </span>
                      <div className="text-xs font-semibold text-[#241F19]/55">
                        ₹{item.price} each
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-3.5">
                      <span className="font-bold text-sm text-[#C4703C] whitespace-nowrap">
                        ₹{item.price * item.quantity}
                      </span>

                      {/* Control Panel */}
                      <div className="flex items-center gap-2 bg-[#1F3B2E] text-[#F6F0E2] px-1.5 py-1 rounded-full">
                        <button
                          onClick={() => onDecreaseQty(item.name, item.category)}
                          className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-white/15 transition-colors cursor-pointer"
                          aria-label="Decrease"
                        >
                          <Minus className="w-2.5 h-2.5" />
                        </button>
                        <span className="font-bold text-xs min-w-[14px] text-center text-[#E7A64C]">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onIncreaseQty(item)}
                          className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-white/15 transition-colors cursor-pointer"
                          aria-label="Increase"
                        >
                          <Plus className="w-2.5 h-2.5" />
                        </button>
                      </div>

                      <button
                        onClick={() => onRemoveItem(key)}
                        className="text-[0.68rem] text-red-600 hover:text-red-700 font-semibold flex items-center gap-1 transition-colors focus:outline-none cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        Remove
                      </button>
                    </div>
                  </div>
                ))
              )}

              {cartEntries.length > 0 && (
                <div className="mt-6 pt-6 border-t-2 border-dashed border-[#241F19]/10 space-y-4">
                  <div className="space-y-1">
                    <h4 className="font-serif font-black text-sm text-[#1F3B2E] tracking-wide uppercase">
                      Dine-In / Order Details
                    </h4>
                    <p className="text-[0.7rem] text-[#241F19]/60 leading-relaxed">
                      Please enter your details to route your order directly to our kitchen staff.
                    </p>
                  </div>

                  <div className="space-y-3.5">
                    {/* Name field */}
                    <div className="space-y-1">
                      <label className="block text-[0.68rem] font-bold text-[#241F19]/70 uppercase tracking-wider">
                        Name <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#241F19]/40">
                          <User className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="text"
                          value={name}
                          onChange={(e) => {
                            setName(e.target.value);
                            if (e.target.value.trim()) setErrors(prev => ({ ...prev, name: false }));
                          }}
                          placeholder="e.g. Pruthiraj Chalan"
                          className={`w-full text-sm pl-9 pr-4 py-2.5 bg-white/60 border rounded-xl focus:outline-none focus:ring-1 focus:bg-white transition-all duration-150 ${
                            errors.name 
                              ? 'border-red-500 focus:border-red-500 focus:ring-red-500 bg-red-50/20' 
                              : 'border-[#241F19]/15 focus:border-[#C4703C] focus:ring-[#C4703C]'
                          }`}
                        />
                      </div>
                      {errors.name && (
                        <p className="text-[0.65rem] text-red-500 font-medium">Name is required to place your order</p>
                      )}
                    </div>

                    {/* Phone field */}
                    <div className="space-y-1">
                      <label className="block text-[0.68rem] font-bold text-[#241F19]/70 uppercase tracking-wider">
                        Phone Number <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#241F19]/40">
                          <Phone className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="tel"
                          value={phone}
                          onChange={(e) => {
                            setPhone(e.target.value);
                            if (e.target.value.trim()) setErrors(prev => ({ ...prev, phone: false }));
                          }}
                          placeholder="e.g. 9876543210"
                          className={`w-full text-sm pl-9 pr-4 py-2.5 bg-white/60 border rounded-xl focus:outline-none focus:ring-1 focus:bg-white transition-all duration-150 ${
                            errors.phone 
                              ? 'border-red-500 focus:border-red-500 focus:ring-red-500 bg-red-50/20' 
                              : 'border-[#241F19]/15 focus:border-[#C4703C] focus:ring-[#C4703C]'
                          }`}
                        />
                      </div>
                      {errors.phone && (
                        <p className="text-[0.65rem] text-red-500 font-medium">Phone number is required</p>
                      )}
                    </div>

                    {/* Dine-In No field */}
                    <div className="space-y-1">
                      <label className="block text-[0.68rem] font-bold text-[#241F19]/70 uppercase tracking-wider">
                        Dine-In Table No <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#241F19]/40">
                          <Hash className="w-3.5 h-3.5" />
                        </div>
                        <input
                          type="tel"
                          inputMode="numeric"
                          value={dineInNo}
                          onChange={(e) => {
                            setDineInNo(e.target.value);
                            if (e.target.value.trim()) setErrors(prev => ({ ...prev, dineInNo: false }));
                          }}
                          placeholder="e.g. 4"
                          className={`w-full text-sm pl-9 pr-4 py-2.5 bg-white/60 border rounded-xl focus:outline-none focus:ring-1 focus:bg-white transition-all duration-150 ${
                            errors.dineInNo 
                              ? 'border-red-500 focus:border-red-500 focus:ring-red-500 bg-red-50/20' 
                              : 'border-[#241F19]/15 focus:border-[#C4703C] focus:ring-[#C4703C]'
                          }`}
                        />
                      </div>
                      {errors.dineInNo && (
                        <p className="text-[0.65rem] text-red-500 font-medium">Dine-in Table number is required</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Total / Checkout Footer */}
            {cartEntries.length > 0 && (
              <div className="p-6 border-t border-[#241F19]/10 bg-[#EDE3CE] space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-[#241F19]/60 text-xs font-semibold uppercase tracking-wider">
                    <span>Subtotal ({totalCount} items)</span>
                    <span>₹{totalAmount}</span>
                  </div>
                  <div className="flex justify-between text-[#241F19]/60 text-xs font-semibold uppercase tracking-wider">
                    <span>GST (5%)</span>
                    <span>₹{gstAmount}</span>
                  </div>
                  <div className="flex justify-between text-[#241F19] text-base font-black border-t border-[#241F19]/10 pt-2">
                    <span className="font-serif">Grand Total</span>
                    <span>₹{grandTotal}</span>
                  </div>
                  <p className="text-[0.68rem] text-[#241F19]/50 leading-relaxed font-normal">
                    *GST included in total. Ordering via WhatsApp launches your custom shopping cart message directly to our chef.
                  </p>
                </div>

                <button
                  onClick={handleWhatsAppCheckout}
                  className="w-full flex items-center justify-center gap-2 py-4 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-base rounded-xl transition-all duration-150 shadow-md hover:-translate-y-0.5 cursor-pointer"
                >
                  Order via WhatsApp
                  <ArrowRight className="w-4.5 h-4.5" />
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
