import React from 'react';
import { Phone, MapPin, Leaf, Mail } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="footer" className="bg-[#16291F] text-[#EDE3CE]/80 pt-16 pb-8 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          
          {/* Column 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#E7A64C]/10 border border-[#E7A64C]/25 flex items-center justify-center">
                <Leaf className="w-4 h-4 text-[#E7A64C]" />
              </div>
              <span className="font-serif text-lg font-black text-[#F6F0E2]">Magnolia</span>
            </div>
            <p className="text-xs sm:text-sm text-[#EDE3CE]/65 leading-relaxed font-normal">
              A premium, offline-first multi-cuisine dining room featuring authentic Asian woks, Italian woodfired styles, tandoori clay options, and traditional South Indian griddles.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Explore Our House
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#menu" className="hover:text-[#F2C97D] transition-colors">
                  Aromatic Food Menu
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#F2C97D] transition-colors">
                  Our Culinary Pillars
                </a>
              </li>
              <li>
                <a href="#reserve" className="hover:text-[#F2C97D] transition-colors">
                  Book A Premium Booth
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact & Visit */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Visit Us
            </h4>
            <div className="flex items-start gap-2.5 text-xs sm:text-sm text-[#EDE3CE]/70">
              <MapPin className="w-4.5 h-4.5 text-[#E7A64C] shrink-0 mt-0.5" />
              <span>
                218/424, near K V COLLEGE, KUKUDAHAD, <br />
                Kantabanji, Dhamandanga, Odisha 767039
              </span>
            </div>
            <div className="flex items-center gap-2.5 text-xs sm:text-sm text-[#EDE3CE]/70">
              <Phone className="w-4.5 h-4.5 text-[#E7A64C] shrink-0" />
              <span>+91 77355 18976</span>
            </div>
            <div className="flex items-center gap-2.5 text-xs sm:text-sm text-[#EDE3CE]/70">
              <Mail className="w-4.5 h-4.5 text-[#E7A64C] shrink-0" />
              <a href="mailto:Pruthirajchalan33@gmail.com" className="hover:text-[#F2C97D] transition-colors">
                Pruthirajchalan33@gmail.com
              </a>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-[#EDE3CE]/45 font-medium">
          <span>&copy; {currentYear} Magnolia Restaurant. All rights reserved.</span>
          <span>Designed with high-contrast warm palettes &amp; negative spacing.</span>
        </div>

      </div>
    </footer>
  );
}
