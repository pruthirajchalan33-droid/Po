import React from 'react';
import { Menu, X, Leaf, Utensils, ShoppingCart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
}

export default function Header({ cartCount, onCartClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { label: 'Menu', href: '#menu' },
    { label: 'Our Story', href: '#about' },
    { label: 'Table Booking', href: '#reserve' },
    { label: 'Find Us', href: '#footer' },
  ];

  const handleLinkClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#F6F0E2]/90 backdrop-blur-md border-b border-[#241F19]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Brand */}
          <a href="#" className="flex items-center gap-3 group focus:outline-none">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-full border border-[#C4703C] bg-[#1F3B2E] transition-transform duration-300 group-hover:scale-105">
              <Leaf className="w-5 h-5 text-[#E7A64C]" />
            </div>
            <div>
              <span className="block font-serif text-xl sm:text-2xl font-black text-[#1F3B2E] tracking-tight">
                Magnolia
              </span>
              <span className="block text-[0.62rem] tracking-[0.22em] font-semibold text-[#C4703C] uppercase -mt-1">
                Restaurant
              </span>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-8 font-medium text-sm text-[#241F19]/80">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleLinkClick(link.href)}
                className="hover:text-[#C4703C] transition-colors focus:outline-none cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Action Call to Actions */}
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={onCartClick}
              className="relative flex items-center gap-2.5 bg-[#1F3B2E] hover:bg-[#16291F] text-[#F6F0E2] font-semibold text-sm px-4 py-2.5 rounded-full shadow-md transition-all duration-200 cursor-pointer"
              id="cart_toggle_button"
            >
              <div className="flex items-center gap-1">
                <Utensils className="w-4 h-4 text-[#E7A64C]" />
                <ShoppingCart className="w-3.5 h-3.5 text-[#E7A64C]/80" />
              </div>
              <span className="hidden sm:inline">My Order</span>
              
              <AnimatePresence mode="popLayout">
                {cartCount > 0 && (
                  <motion.span
                    key={cartCount}
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.4, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 400, damping: 15 }}
                    className="flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-[#E7A64C] text-[#241F19] text-xs font-bold leading-none"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>

            {/* Mobile Menu Icon */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-full hover:bg-[#241F19]/5 md:hidden text-[#1F3B2E] focus:outline-none cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden bg-[#F6F0E2] border-t border-[#241F19]/10 overflow-hidden"
          >
            <div className="px-4 py-4 space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleLinkClick(link.href)}
                  className="block w-full text-left font-serif text-lg py-2.5 px-4 rounded-xl hover:bg-[#1F3B2E]/5 text-[#1F3B2E] font-semibold transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
