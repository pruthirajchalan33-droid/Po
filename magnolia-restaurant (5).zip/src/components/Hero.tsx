import React from 'react';
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const heroImage = '/src/assets/images/magnolia_cartoon_hero_with_text_1784962500718.jpg';

interface HeroProps {
  onExploreMenu: () => void;
  onBookTable: () => void;
}

export default function Hero({ onExploreMenu, onBookTable }: HeroProps) {
  return (
    <section 
      id="hero" 
      className="relative h-[92vh] sm:h-screen w-full flex items-center justify-center bg-[#112018] overflow-hidden"
    >
      {/* Pristine Fullscreen Image Showcase */}
      <div className="absolute inset-0 w-full h-full z-0">
        <img
          src={heroImage}
          alt="Magnolia boutique interior featuring cozy warm hanging lanterns, comfortable seating booths, hand-painted tropical murals, and fully laid vegetarian tables"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover select-none"
        />
        {/* Subtle top/bottom vignetting and blend gradients to tie with header and next sections */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#112018]/60 via-[#112018]/30 to-[#112018]/95 z-10 pointer-events-none" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#112018] to-transparent z-10 pointer-events-none" />
      </div>

      {/* Elegant, Minimalistic Scroll Indicator at the bottom */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: [0, 8, 0] }}
        transition={{ 
          opacity: { duration: 0.8, delay: 0.9 },
          y: { repeat: Infinity, duration: 2, ease: "easeInOut" }
        }}
        onClick={onExploreMenu}
        className="absolute bottom-10 z-20 flex flex-col items-center gap-2.5 cursor-pointer group"
      >
        <span className="text-[10px] uppercase tracking-[0.25em] text-[#EDE3CE] font-bold bg-[#112018]/65 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 group-hover:border-[#F2C97D]/45 transition-colors duration-200">
          Scroll to Explore
        </span>
        <ChevronDown className="w-5 h-5 text-[#F2C97D] drop-shadow-md group-hover:scale-110 transition-transform duration-200" />
      </motion.div>
    </section>
  );
}
