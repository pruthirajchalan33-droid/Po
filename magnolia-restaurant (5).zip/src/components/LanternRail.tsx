import React from 'react';

export default function LanternRail() {
  // Generate 24 animated fairy lights along a draping curve
  const bulbs = Array.from({ length: 24 }).map((_, i) => {
    const cx = (i / 23) * 100; // Percentage of width
    const cy = 6 + Math.sin(i * 0.9) * 14 + 20; // Draping wave height
    // Stagger animation delays for a natural twinkling effect
    const animationDelay = `${(i % 5) * 0.6}s`;
    return { cx, cy, animationDelay };
  });

  return (
    <div className="relative h-14 bg-[#16291F] overflow-hidden border-b border-white/5" aria-hidden="true">
      <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 64">
        {/* Decorative Draping Gold Wire */}
        <path
          d="M 0,10 Q 12.5,42 25,10 T 50,10 T 75,10 T 100,10"
          stroke="rgba(231,166,76,0.25)"
          strokeWidth="0.4"
          fill="none"
        />
        {/* Hanging Bulbs */}
        {bulbs.map((bulb, idx) => (
          <circle
            key={idx}
            cx={bulb.cx}
            cy={bulb.cy}
            r="0.8"
            className="animate-pulse"
            style={{
              fill: '#E7A64C',
              animation: 'flicker 2.5s ease-in-out infinite',
              animationDelay: bulb.animationDelay,
              filter: 'drop-shadow(0 0 4px #E7A64C)',
            }}
          />
        ))}
      </svg>
      {/* Dynamic Keyframes injected globally for twinkling */}
      <style>{`
        @keyframes flicker {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.35; transform: scale(0.85); }
        }
      `}</style>
    </div>
  );
}
