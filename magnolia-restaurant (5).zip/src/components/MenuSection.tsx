import React, { useState, useMemo } from 'react';
import { Search, Star, Sparkles, X, Plus, Minus, ArrowRight } from 'lucide-react';
import { menuData, getFoodEmoji } from '../data/menu';
import { CartItem, MenuItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface MenuSectionProps {
  cart: { [key: string]: CartItem };
  onAddToCart: (item: MenuItem, category: string) => void;
  onDecreaseInCart: (itemName: string, category: string) => void;
  onOpenCart: () => void;
}

export default function MenuSection({ cart, onAddToCart, onDecreaseInCart, onOpenCart }: MenuSectionProps) {
  const categories = Object.keys(menuData);
  const [selectedCategory, setSelectedCategory] = useState<string>(categories[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Find quantity of an item in the cart
  const getItemQty = (itemName: string, category: string) => {
    const key = `${category}|||${itemName}`;
    return cart[key]?.quantity || 0;
  };

  // Search filter across categories
  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.toLowerCase();
    const results: { category: string; item: MenuItem }[] = [];
    
    Object.entries(menuData).forEach(([category, items]) => {
      items.forEach((item) => {
        if (
          item.name.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query)
        ) {
          results.push({ category, item });
        }
      });
    });
    return results;
  }, [searchQuery]);

  const activeCategoryItems = menuData[selectedCategory] || [];

  return (
    <section id="menu" className="bg-[#F6F0E2] py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 mb-12">
          <div>
            <span className="text-xs font-bold tracking-[0.2em] text-[#C4703C] uppercase block mb-2">
              Browse Our Counters
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-black text-[#1F3B2E] tracking-tight">
              Pick your cuisine, build your plate.
            </h2>
          </div>
          <div className="w-full lg:max-w-xs">
            <div className="relative">
              <input
                type="text"
                placeholder="Search 150+ pure veg dishes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-[#EDE3CE] border border-[#241F19]/14 rounded-full text-[#241F19] placeholder-[#241F19]/50 focus:outline-none focus:border-[#C4703C] transition-colors font-medium text-sm"
              />
              <Search className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-[#241F19]/50" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-3.5 hover:text-[#C4703C]"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Category Tabs Switcher (Only if not actively searching) */}
        {!searchQuery && (
          <div className="flex gap-2.5 overflow-x-auto pb-4 mb-10 scrollbar-thin scrollbar-thumb-[#241F19]/14 scrollbar-track-transparent">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-sm font-semibold transition-all shrink-0 cursor-pointer border ${
                  selectedCategory === cat
                    ? 'bg-[#1F3B2E] text-[#F6F0E2] border-[#1F3B2E]'
                    : 'bg-[#EDE3CE] text-[#241F19]/70 border-[#241F19]/10 hover:border-[#241F19]/30 hover:text-[#241F19]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Search Results Summary */}
        {searchQuery && (
          <div className="mb-8 flex items-center justify-between">
            <h3 className="text-lg font-serif text-[#1F3B2E] font-bold">
              Search Results for "{searchQuery}" ({filteredResults?.length || 0} found)
            </h3>
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs font-bold text-[#C4703C] hover:underline"
            >
              Back to Categories
            </button>
          </div>
        )}

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {searchQuery ? (
            /* Search Mode Rendering */
            filteredResults && filteredResults.length > 0 ? (
              filteredResults.map(({ category, item }) => (
                <MenuItemCard
                  key={`${category}-${item.name}`}
                  item={item}
                  category={category}
                  quantity={getItemQty(item.name, category)}
                  onAdd={() => onAddToCart(item, category)}
                  onDecrease={() => onDecreaseInCart(item.name, category)}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-16 bg-[#EDE3CE]/40 rounded-3xl border border-dashed border-[#241F19]/10">
                <p className="text-[#241F19]/50 text-base font-medium mb-3">No dishes found matching your search.</p>
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 bg-[#1F3B2E] text-[#F6F0E2] text-xs font-bold rounded-full"
                >
                  View All Categories
                </button>
              </div>
            )
          ) : (
            /* Standard Category Menu Grid */
            activeCategoryItems.map((item) => (
              <MenuItemCard
                key={`${selectedCategory}-${item.name}`}
                item={item}
                category={selectedCategory}
                quantity={getItemQty(item.name, selectedCategory)}
                onAdd={() => onAddToCart(item, selectedCategory)}
                onDecrease={() => onDecreaseInCart(item.name, selectedCategory)}
              />
            ))
          )}
        </div>

        {/* Floating Cart Indicator Bar on Mobile/Sticky Drawer button */}
        {Object.keys(cart).length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-6 left-6 right-6 md:left-auto md:right-8 z-30 max-w-sm"
          >
            <button
              onClick={onOpenCart}
              className="w-full flex items-center justify-between bg-[#C4703C] hover:bg-[#A85A2C] text-white px-5 py-4 rounded-2xl shadow-xl transition-transform active:scale-95 cursor-pointer font-bold"
            >
              <div className="flex items-center gap-3">
                <span className="bg-white/20 text-white rounded-lg px-2 py-0.5 text-xs">
                  {Object.values(cart).reduce((s, x) => s + x.quantity, 0)} Items
                </span>
                <span className="text-sm">View Basket</span>
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                ₹{Object.values(cart).reduce((s, x) => s + (x.quantity * x.price), 0)}
                <ArrowRight className="w-4 h-4" />
              </div>
            </button>
          </motion.div>
        )}

      </div>
    </section>
  );
}

/* ================= REUSABLE MENU ITEM CARD ================= */
interface CardProps {
  key?: string;
  item: MenuItem;
  category: string;
  quantity: number;
  onAdd: () => void;
  onDecrease: () => void;
}

function MenuItemCard({ item, category, quantity, onAdd, onDecrease }: CardProps) {
  return (
    <motion.div
      layout
      className="bg-[#EDE3CE]/80 hover:bg-[#EDE3CE] rounded-2xl p-6 border border-[#241F19]/8 flex flex-col justify-between transition-all duration-200 group relative"
    >
      <div>
        <div className="flex justify-between items-start gap-3 mb-2">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#EDE3CE] border border-[#241F19]/8 text-sm shrink-0 select-none shadow-sm group-hover:bg-[#F6F0E2] transition-colors duration-200" title={item.name}>
                {getFoodEmoji(item.name, category)}
              </span>
              <span className="inline-flex items-center justify-center w-4 h-4 rounded border border-emerald-600 bg-emerald-50 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
              </span>
              <h4 className="font-serif font-bold text-[#1F3B2E] text-base group-hover:text-[#C4703C] transition-colors leading-tight">
                {item.name}
              </h4>
            </div>
            <span className="inline-block text-[0.68rem] font-bold text-[#241F19]/40 uppercase tracking-wide">
              {category}
            </span>
          </div>
          <span className="font-bold text-base text-[#C4703C] whitespace-nowrap">
            ₹{item.price}
          </span>
        </div>

        {item.description && (
          <p className="text-xs text-[#241F19]/65 leading-relaxed mb-6 font-normal">
            {item.description}
          </p>
        )}
      </div>

      <div className="flex justify-between items-center mt-auto pt-3 border-t border-[#241F19]/5">
        {/* Popular / Chef Special badge */}
        <div>
          {item.isPopular && (
            <span className="inline-flex items-center gap-1 text-[0.62rem] font-bold text-[#C4703C] bg-[#C4703C]/10 px-2 py-0.5 rounded-full">
              <Star className="w-2.5 h-2.5 fill-[#C4703C] text-transparent" />
              Popular
            </span>
          )}
        </div>

        {/* Counter controls */}
        <div>
          {quantity === 0 ? (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={onAdd}
              className="px-4 py-1.5 bg-[#1F3B2E] hover:bg-[#16291F] text-[#F6F0E2] text-xs font-bold rounded-full shadow-sm hover:shadow transition-all duration-150 cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-3 h-3 text-[#E7A64C]" />
              Add
            </motion.button>
          ) : (
            <div className="flex items-center gap-3 bg-[#1F3B2E] text-[#F6F0E2] px-2 py-1.5 rounded-full shadow-sm">
              <button
                onClick={onDecrease}
                className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-white/10 active:scale-90 transition-transform cursor-pointer"
                aria-label="Decrease quantity"
              >
                <Minus className="w-3 h-3 text-[#EDE3CE]" />
              </button>
              <span className="font-bold text-xs min-w-[14px] text-center text-[#E7A64C]">
                {quantity}
              </span>
              <button
                onClick={onAdd}
                className="w-5 h-5 flex items-center justify-center rounded-full hover:bg-white/10 active:scale-90 transition-transform cursor-pointer"
                aria-label="Increase quantity"
              >
                <Plus className="w-3 h-3 text-[#EDE3CE]" />
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
