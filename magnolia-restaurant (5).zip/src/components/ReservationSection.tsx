import React, { useState } from 'react';
import { Calendar, Phone, Users, Clock, CheckCircle2, MessageSquare, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function ReservationSection() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [guests, setGuests] = useState('2');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Set today's date as the minimum selectable date
  const todayString = new Date().toISOString().split('T')[0];

  const formatToAMPM = (timeStr: string) => {
    if (!timeStr) return '';
    const [hoursStr, minutesStr] = timeStr.split(':');
    let hours = parseInt(hoursStr, 10);
    const minutes = minutesStr || '00';
    if (isNaN(hours)) return timeStr;
    
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    
    const formattedHours = hours < 10 ? `0${hours}` : hours;
    return `${formattedHours}:${minutes} ${ampm}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);

    const formattedTime = formatToAMPM(time);

    const message = `Hi Magnolia! I'd like to reserve a table for dining:\n\n` +
      `👤 Name: ${name}\n` +
      `📞 Contact: ${phone}\n` +
      `📅 Date: ${date}\n` +
      `⏰ Time: ${formattedTime}\n` +
      `👥 Party Size: ${guests} guests\n` +
      `\nPlease confirm our booth. Thank you!`;

    // Opens user's WhatsApp with pre-filled message instantly
    const url = `https://wa.me/917735518976?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleWhatsAppTrigger = () => {
    const formattedTime = formatToAMPM(time);

    const message = `Hi Magnolia! I'd like to reserve a table for dining:\n\n` +
      `👤 Name: ${name}\n` +
      `📞 Contact: ${phone}\n` +
      `📅 Date: ${date}\n` +
      `⏰ Time: ${formattedTime}\n` +
      `👥 Party Size: ${guests} guests\n` +
      `\nPlease confirm our booth. Thank you!`;

    // Opens user's WhatsApp with pre-filled message
    const url = `https://wa.me/917735518976?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleResetForm = () => {
    setName('');
    setPhone('');
    setDate('');
    setTime('');
    setGuests('2');
    setIsSubmitted(false);
  };

  return (
    <section id="reserve" className="bg-[#1F3B2E] text-[#F6F0E2] py-16 lg:py-24 relative overflow-hidden">
      {/* Background visual detail */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,rgba(196,112,60,0.15),transparent_60%)] pointer-events-none" />

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center space-y-3 mb-8">
          <span className="text-xs font-bold tracking-[0.2em] text-[#F2C97D] uppercase block">
            Reserve A Table
          </span>
          <p className="text-sm text-[#EDE3CE]/85 max-w-lg mx-auto leading-relaxed">
            Secure your table today! Experience exceptional culinary delights, cozy ambiance, and flawless hospitality tailored just for you. Reserve now!
          </p>
        </div>

        {/* Form / Success Card Column */}
        <div className="w-full">
          <div className="bg-[#F6F0E2] text-[#241F19] p-8 sm:p-10 rounded-3xl border border-white/10 shadow-2xl relative min-h-[420px] flex flex-col justify-center">
              
              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.form
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="space-y-5"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-xs font-bold text-[#1F3B2E] uppercase tracking-wider mb-2">
                          Your Name
                        </label>
                        <input
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Full name"
                          className="w-full px-4 py-3 bg-[#EDE3CE]/50 border border-[#241F19]/14 rounded-xl text-[#241F19] placeholder-[#241F19]/45 focus:outline-none focus:border-[#C4703C] transition-colors font-semibold text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-[#1F3B2E] uppercase tracking-wider mb-2">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+91 XXXXX XXXXX"
                          className="w-full px-4 py-3 bg-[#EDE3CE]/50 border border-[#241F19]/14 rounded-xl text-[#241F19] placeholder-[#241F19]/45 focus:outline-none focus:border-[#C4703C] transition-colors font-semibold text-sm"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-xs font-bold text-[#1F3B2E] uppercase tracking-wider mb-2">
                          Date
                        </label>
                        <div className="relative">
                          <input
                            type="date"
                            required
                            min={todayString}
                            value={date}
                            onChange={(e) => setDate(e.target.value)}
                            className="w-full px-4 py-3 bg-[#EDE3CE]/50 border border-[#241F19]/14 rounded-xl text-[#241F19] focus:outline-none focus:border-[#C4703C] transition-colors font-semibold text-sm appearance-none"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-[#1F3B2E] uppercase tracking-wider mb-2">
                          Time
                        </label>
                        <input
                          type="time"
                          required
                          value={time}
                          onChange={(e) => setTime(e.target.value)}
                          className="w-full px-4 py-3 bg-[#EDE3CE]/50 border border-[#241F19]/14 rounded-xl text-[#241F19] focus:outline-none focus:border-[#C4703C] transition-colors font-semibold text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1F3B2E] uppercase tracking-wider mb-2">
                        Number of Guests
                      </label>
                      <div className="relative flex items-center bg-[#EDE3CE]/50 border border-[#241F19]/14 rounded-xl overflow-hidden focus-within:border-[#C4703C] transition-colors">
                        <button
                          type="button"
                          onClick={() => {
                            const val = parseInt(guests, 10) || 1;
                            if (val > 1) setGuests((val - 1).toString());
                          }}
                          className="px-4 py-3 text-[#1F3B2E] hover:bg-[#EDE3CE]/70 active:bg-[#EDE3CE]/90 transition-colors font-bold text-lg select-none cursor-pointer"
                        >
                          −
                        </button>
                        <input
                          type="number"
                          required
                          pattern="[0-9]*"
                          inputMode="numeric"
                          min="1"
                          max="99"
                          value={guests}
                          onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9]/g, '');
                            setGuests(val);
                          }}
                          className="w-full py-3 bg-transparent text-center text-[#241F19] focus:outline-none font-bold text-base [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const val = parseInt(guests, 10) || 0;
                            setGuests((val + 1).toString());
                          }}
                          className="px-4 py-3 text-[#1F3B2E] hover:bg-[#EDE3CE]/70 active:bg-[#EDE3CE]/90 transition-colors font-bold text-lg select-none cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-4 bg-[#C4703C] hover:bg-[#A85A2C] text-white font-bold text-sm sm:text-base rounded-xl transition-all duration-150 cursor-pointer shadow-md hover:-translate-y-0.5 mt-2"
                    >
                      Booking
                    </button>
                  </motion.form>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="text-center space-y-6 py-6"
                  >
                    <div className="flex justify-center">
                      <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center border border-emerald-200">
                        <CheckCircle2 className="w-9 h-9 text-emerald-600" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-serif text-2xl font-black text-[#1F3B2E]">
                        Details verified successfully!
                      </h3>
                      <p className="text-sm text-[#241F19]/70 max-w-md mx-auto leading-relaxed">
                        To lock in your booth and notify our hosts, please send the reservation slip directly to our concierge team via WhatsApp.
                      </p>
                    </div>

                    <div className="bg-[#EDE3CE] rounded-2xl p-5 border border-[#241F19]/10 text-left max-w-md mx-auto space-y-2 text-sm text-[#241F19]/80 font-medium">
                      <div><span className="text-[#241F19]/50 text-xs uppercase font-bold tracking-wider">Guest:</span> {name}</div>
                      <div className="grid grid-cols-2 gap-2">
                        <div><span className="text-[#241F19]/50 text-xs uppercase font-bold tracking-wider">Date:</span> {date}</div>
                        <div><span className="text-[#241F19]/50 text-xs uppercase font-bold tracking-wider">Time:</span> {formatToAMPM(time)}</div>
                      </div>
                      <div><span className="text-[#241F19]/50 text-xs uppercase font-bold tracking-wider">Party Size:</span> {guests} {parseInt(guests, 10) === 1 ? 'guest' : 'guests'}</div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto pt-2">
                      <button
                        onClick={handleWhatsAppTrigger}
                        className="flex-1 flex items-center justify-center gap-2 py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm rounded-xl transition-all duration-150 shadow-md cursor-pointer"
                      >
                        <MessageSquare className="w-4.5 h-4.5 fill-white" />
                        Send to WhatsApp
                      </button>
                      <button
                        onClick={handleResetForm}
                        className="py-3.5 px-5 bg-transparent border border-[#241F19]/20 hover:border-[#C4703C] hover:text-[#C4703C] font-semibold text-sm rounded-xl transition-all duration-150 cursor-pointer"
                      >
                        Modify Booking
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </div>
        </div>
      </section>
  );
}
