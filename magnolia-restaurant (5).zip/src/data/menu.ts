import { MenuData } from '../types';

export const menuData: MenuData = {
  "Soups": [
    { name: "Minestrone Soup", price: 139, description: "Traditional Italian soup with beans, pasta and lots of vegetables.", isPopular: true },
    { name: "Veg Manchow Soup", price: 99, description: "Spicy veg soup, perfect with crispy noodles." },
    { name: "Veg Hot N Sour Soup", price: 99, description: "Mixed vegetables, mushrooms, spices and soy sauce." },
    { name: "Lemon Coriander Soup", price: 99, description: "Lemon-yellow delight with tantalizing citrus-y flavours." },
    { name: "Sweet Corn Soup", price: 99, description: "Creamy soup with mixed vegetables and American corn." },
    { name: "Veg Clear Soup", price: 99, description: "Healthy mixed vegetable soup in a clear stock." },
    { name: "Wonton Soup", price: 119, description: "Paper-thin wrapper filled with tofu, carrot, mushroom and ginger." },
    { name: "Talumein Soup", price: 119, description: "Flavoured with noodles and veggies in soy sauce." },
    { name: "Tomato Soup", price: 119, description: "Plump tomatoes and carrots cooked with mild spices and butter." }
  ],
  "Starters & Tandoor": [
    { name: "Bharwan Paneer Tikka", price: 269, description: "Paneer stuffed with dry fruit mixture, marinated in spiced yogurt.", isPopular: true },
    { name: "Hara Bhara Kebab", price: 219, description: "Chana dal, green peas, paneer, spinach and Indian spices." },
    { name: "Veg Kakori Kebab", price: 249, description: "Mughlai dish with mix veg, onions and lots of spice." },
    { name: "Veg Seekh Kebab", price: 259, description: "Mixed vegetables and spices, grilled to a smoky finish." },
    { name: "Tandoori Platter", price: 359, description: "A mixture of kebabs served with mint sauce.", isPopular: true },
    { name: "Aloo Adraki Tikki", price: 219, description: "Mashed potato prepared with ginger-flavoured tikki." },
    { name: "Sunheri Khasta", price: 239, description: "A desi version of the crispy spring roll." },
    { name: "Matar ki Tikki", price: 169, description: "Crushed green peas cooked with mash potato and ginger-garlic." },
    { name: "Paneer Tikka", price: 239, description: "Cottage cheese cubes marinated in a spiced yogurt base." },
    { name: "Paneer Pudina Tikka", price: 239, description: "Coated with fresh mint paste, marinated and grilled in clay oven." },
    { name: "Paneer Pahadi Tikka", price: 239, description: "Green chillies, mint and coriander for a well-balanced taste." },
    { name: "Paneer Hazrat", price: 259, description: "Spicy, garlicky cottage cheese with the aroma of saffron." },
    { name: "Russian Salad", price: 119, description: "Mixed vegetables in a mayonnaise dressing." },
    { name: "Chef Special Salad", price: 149, description: "Exotic veggies tossed in corn and bell pepper, herb dressing." },
    { name: "Onion Salad", price: 49, description: "Simply sliced onions with condiments." }
  ],
  "Asian Wok": [
    { name: "Hakka Noodles", price: 199, description: "Boiled noodles and stir-fried vegetables in Chinese sauces." },
    { name: "Chilly Garlic Noodles", price: 199, description: "Stir-fried noodles with red dried chilli in garlic flavour." },
    { name: "Schezwan Noodles", price: 199, description: "Stir-fried noodles prepared with schezwan sauce." },
    { name: "Baizing Noodles", price: 219, description: "Noodles prepared with turmeric in an oyster sauce flavour." },
    { name: "Veg Fried Rice", price: 169, description: "Rice prepared to perfection with chopped vegetables." },
    { name: "Schezwan Fried Rice", price: 179, description: "Rice tossed with the addition of schezwan sauce." },
    { name: "Triple Schezwan Fried Rice", price: 229, description: "A combination of schezwan rice with fried noodles.", isPopular: true },
    { name: "Mongolian Rice & Noodles", price: 299, description: "Stir-fried veggies combined with rice and noodles in Hoisin sauce." },
    { name: "Chinese Combo (Rice or Noodles)", price: 299, description: "A Chinese preparation of rice and noodles together." },
    { name: "Back to China", price: 359, description: "Combination of flat noodle, Manchurian and fried rice.", isPopular: true },
    { name: "Teppanyaki Sizzler", price: 339, description: "Stir-fried veg, noodles and rice served Teppanyaki style." },
    { name: "Paneer Chilly Dry", price: 219, description: "Crispy paneer tossed in soy, vinegar and chilli sauce." },
    { name: "Veg Manchurian Dry", price: 169, description: "Golden-fried veggie balls in a spicy soya sauce, coriander finish." },
    { name: "Potato Chilly", price: 169, description: "A popular Indo-Chinese starter and snack." },
    { name: "Lovely Corn", price: 219, description: "Crispy corn tossed in sweet chilli sauce." },
    { name: "Paneer 65", price: 219, description: "Deep-fried crispy paneer with Chinese spices, South style." },
    { name: "Veg Spring Roll", price: 199, description: "Crispy rolls filled with a savoury vegetable stuffing." },
    { name: "Korean Roll", price: 199, description: "Crispy vegetable rolls served with a Korean dip." },
    { name: "Steamed Momos", price: 179, description: "Minced vegetables marinated in Himalayan spices, steamed." },
    { name: "Crispy Chilly Baby Corn", price: 229, description: "Crispy baby corn tossed in sweet chilli-garlic sauce." },
    { name: "Mushroom Chilly", price: 229, description: "Batter-fried mushrooms tossed in sweet and spicy chilli sauce." }
  ],
  "Italian": [
    { name: "Pasta (Red / White / Mix / Pink Sauce)", price: 269, description: "Choice of pasta tossed with Italian herbs in your favourite sauce.", isPopular: true },
    { name: "Grilled Paneer", price: 309, description: "Grilled cottage cheese, rice and sauteed vegetables in BBQ dip." },
    { name: "Vegetable Stroganoff", price: 309, description: "Seasonal vegetables in brown sauce with onion, tomato, capsicum." },
    { name: "Exotic Vegetable Sizzler", price: 369, description: "Exotic vegetables and rice with special herbs and sauces.", isPopular: true },
    { name: "Paneer Shashlik", price: 309, description: "Paneer and veggies grilled with spicy sauce, served on a hot plate." },
    { name: "Paneer Chilly Sizzler", price: 339, description: "Paneer chilly grilled with spicy sauce, served on a hot plate." },
    { name: "Cheese Balls", price: 329, description: "Lightly spiced cheese stuffed into mashed potato." },
    { name: "Jalapeno Poppers", price: 299, description: "Jalapenos with mashed potato in a creamy cheese filling." },
    { name: "Potato Nuggets", price: 269, description: "Potatoes, cheese and bread crumbs with herbs." },
    { name: "French Fry", price: 129, description: "Thin finger-cut potatoes, deep-fried and lightly spiced." },
    { name: "Cheese French Fry", price: 159, description: "French fry topped with melted cheese and mayo dip." },
    { name: "Peri Peri French Fry", price: 139, description: "French fry tossed in peri peri masala." },
    { name: "Honey Chilli French Fry", price: 139, description: "French fry tossed with honey and chilli flakes." },
    { name: "Paneer Finger", price: 289, description: "Battered paneer fingers coated in bread crumbs, mayo dip." },
    { name: "Potato Finger", price: 179, description: "Battered mashed potato fingers, bread crumb coating." },
    { name: "Vegetable Finger", price: 199, description: "Finely chopped vegetable fingers, crumbed and deep-fried." },
    { name: "Banmali Special French Fry", price: 199, description: "House special loaded fries with mixed vegetables." }
  ],
  "Pizza & Burgers": [
    { name: "Margherita Pizza", price: 199, description: "Tomatoes, mozzarella cheese and fresh basil." },
    { name: "Farm House Pizza", price: 219, description: "Thin crust with exotic farmhouse vegetables and concasse sauce.", isPopular: true },
    { name: "Cheese N Corn Pizza", price: 219, description: "Stuffed with cheese and corn." },
    { name: "Sicilian Pizza", price: 279, description: "Fluffy base topped with tomatoes, onions, herbs and olives." },
    { name: "Paneer Chilly Pizza", price: 299, description: "Cottage cheese, onion, capsicum and Chinese spices." },
    { name: "Mexican Pizza", price: 299, description: "Fresh vegetables with Mexican-style sauce." },
    { name: "Chef Special Pizza", price: 249, description: "Onion, capsicum, mushroom, baby corn and fresh cottage cheese.", isPopular: true },
    { name: "Plain Burger", price: 89, description: "A bread bun stuffed with lettuce and tomatoes." },
    { name: "Cheese Burger", price: 109, description: "Lettuce, tomato and cheese in a soft bun." },
    { name: "Cheese Corn Burger", price: 139, description: "Bread bun stuffed with cheese and corn." },
    { name: "French Style Burger", price: 169, description: "Iceberg lettuce and French herbs in a bun." },
    { name: "Mumbai Style Burger", price: 149, description: "Mumbai spices with vegetables and cheese." },
    { name: "Chef Special Burger", price: 199, description: "Jalapeno, olive, cheese and lettuce, all in one bun." }
  ],
  "Sandwiches": [
    { name: "Plain Sandwich", price: 99, description: "Cucumber and tomato, topped with Indian condiments." },
    { name: "Club Sandwich", price: 189, description: "Club-style, served with a mayo dip." },
    { name: "Veg Grilled Sandwich", price: 139, description: "Grilled sandwich with melted cheese." },
    { name: "Mumbai Sandwich", price: 159, description: "Triple decker, stuffed with spicy potato masala, schezwan dip.", isPopular: true },
    { name: "Cheese Grilled Sandwich", price: 149, description: "Stuffed with roasted cottage cheese." },
    { name: "Cheese Corn Grilled Sandwich", price: 169, description: "Stuffed with cheese and raw vegetables." },
    { name: "Exotic Veg Grilled Sandwich", price: 169, description: "Exotic vegetables and cheese, served with mayo." },
    { name: "Garlic Bread", price: 149, description: "Topped with garlic and herbs." },
    { name: "Cheese Garlic Bread", price: 169, description: "Spread with cheese and chopped garlic." },
    { name: "Cheese Chilli Toast", price: 199, description: "Crisp toast with bell pepper and cheese, baked in oven.", isPopular: true },
    { name: "Mexican Sandwich", price: 199, description: "Vegetable filling served in an exotic style." }
  ],
  "Indian Mains": [
    { name: "Paneer Butter Masala", price: 219, description: "Rich, creamy curry with paneer, onions, tomatoes, cashews and butter.", isPopular: true },
    { name: "Paneer Kadhai", price: 219, description: "Ground kadhai masala with paneer, onions, tomatoes and bell peppers." },
    { name: "Paneer Methi Chaman", price: 219, description: "Kashmiri-style fenugreek leaves and cottage cheese." },
    { name: "Paneer Khurchan", price: 229, description: "Paneer fingers with julienned onion and capsicum." },
    { name: "Paneer Kolhapuri", price: 229, description: "Spicy Kolhapuri-style cottage cheese gravy." },
    { name: "Subz Nilgiri", price: 219, description: "South Indian style veg in spinach and coriander gravy." },
    { name: "Subz Navratan", price: 219, description: "Mixed vegetables in a cashew-nut white gravy." },
    { name: "Subz Kadhai", price: 199, description: "Diced assorted vegetables in kadhai masala." },
    { name: "Subz Diwani Handi", price: 199, description: "Mixed veggies prepared in a spinach base." },
    { name: "Subz Chulbuli", price: 199, description: "Finely chopped vegetables in a rich yellow gravy." },
    { name: "Mix Veg", price: 199, description: "Assorted vegetables in yellow gravy with Indian condiments." },
    { name: "Subz Panjabi", price: 119, description: "Mixed vegetables in a red spicy gravy." },
    { name: "Dal Fry", price: 99, description: "Yellow lentils tempered with onion, tomato, garlic and cumin." },
    { name: "Tadkewali Dal", price: 129, description: "Yellow lentils with a double tadka." },
    { name: "Dal Makhni", price: 159, description: "Black dal and kidney beans, rich and creamy.", isPopular: true },
    { name: "Steam Rice", price: 89, description: "Plain steamed basmati rice." },
    { name: "Jeera Rice", price: 99, description: "Basmati rice tossed with cumin seeds and coriander." },
    { name: "Veg Dum Biryani", price: 189, description: "Exotic rice with spicy vegetables, salan and raita.", isPopular: true },
    { name: "Veg Pulao", price: 179, description: "Rice and vegetables prepared with a light yellow tinge." },
    { name: "Green Salad", price: 79, description: "Cucumber, tomato and carrot slices." }
  ],
  "South Indian": [
    { name: "Idli", price: 59, description: "Steamed rice cakes made from rice and urad dal batter." },
    { name: "Plain Dosa", price: 79, description: "Paper-thin pancake served with South Indian chutney." },
    { name: "Masala Dosa", price: 99, description: "Stuffed with potato masala vegetable and fries." },
    { name: "Ginni Dosa", price: 149, description: "Crispy, cheesy dosa with a spicy, sour-sweet taste.", isPopular: true },
    { name: "Mexican Dosa", price: 139, description: "Roasted veg salad, cheese, baked beans and red chilli sauce." },
    { name: "Pizza Dosa", price: 199, description: "Dosa served in pizza style." },
    { name: "Steamed Dosa", price: 199, description: "Oil-free dosa topped with potato masala." },
    { name: "Cheese Masala Dosa", price: 249, description: "Topped with grated cheese and masala." },
    { name: "Mysore Masala Dosa", price: 199, description: "With the taste of spicy Mysore chutney." },
    { name: "Rava Plain Dosa", price: 89, description: "Lacy dosa made with semolina and rice flour." },
    { name: "Rava Masala Dosa", price: 99, description: "Semolina, rice flour, onion, butter and masala." },
    { name: "Rava Onion Dosa", price: 89, description: "Semolina, rice flour and onion, with Indian spice." },
    { name: "Upma", price: 79, description: "Semolina cooked with onion, green chilli, carrot, beans and peas." },
    { name: "Poori Sabji", price: 119, description: "Puffed fried bread with a spiced, tangy potato dish.", isPopular: true },
    { name: "Chole Bhature", price: 119, description: "Spicy chana masala with fried maida bread.", isPopular: true },
    { name: "Medu Wada", price: 129, description: "Crispy-exterior vada prepared from urad dal." }
  ],
  "Indian Breads": [
    { name: "Tawa Roti Plain", price: 20, description: "Soft wheat flatbread cooked on griddle." },
    { name: "Tawa Butter Roti", price: 25, description: "Soft wheat flatbread with a brush of pure ghee." },
    { name: "Khasta Roti", price: 65, description: "Crisp and flaky oven-baked Indian bread." },
    { name: "Plain Paratha", price: 65, description: "Layered whole wheat pan-fried bread." },
    { name: "Onion Paratha", price: 79, description: "Flatbread stuffed with spiced chopped onions." },
    { name: "Aloo Paratha", price: 79, description: "Golden wheat flatbread stuffed with spiced mashed potatoes." },
    { name: "Lachha Paratha", price: 89, description: "Multi-layered flaky wheat bread cooked in clay oven." },
    { name: "Paneer Paratha", price: 99, description: "Spiced grated cottage cheese stuffed flatbread." },
    { name: "Tandoori Roti Plain", price: 35, description: "Whole wheat bread baked in tandoori clay oven." },
    { name: "Tandoori Butter Roti", price: 40, description: "Freshly tandoor-baked roti with delicious butter." },
    { name: "Paneer Kulcha", price: 119, description: "Traditional soft leavened bread stuffed with cottage cheese." },
    { name: "Masala Kulcha", price: 119, description: "Leavened bread filled with mixed spices and potatoes." },
    { name: "Missi Roti", price: 65, description: "Savory gram-flour flatbread with herbs and spices." },
    { name: "Garlic Naan", price: 79, description: "Clay oven-baked naan infused with minced garlic and butter." },
    { name: "Butter Naan", price: 69, description: "Classic tandoori flatbread with generous butter.", isPopular: true },
    { name: "Plain Naan", price: 59, description: "Traditional soft flatbread baked in the tandoor." }
  ],
  "Beverages & Mocktails": [
    { name: "Jaljeera", price: 49, description: "Tangy cumin-spiced cooling water drink with mint and lemon." },
    { name: "Water Bottle (1 Ltr)", price: 20, description: "Chilled mineral water." },
    { name: "Soda (500 ml)", price: 45, description: "Extra-fizzy carbonated soda water." },
    { name: "Cold Drinks (Glass)", price: 30, description: "Assorted carbonated sodas served over ice." },
    { name: "Tea", price: 49, description: "A comforting blend of milk and premium tea." },
    { name: "Masala Tea", price: 49, description: "Traditional Indian chai brewed with cardamoms, ginger, and cloves." },
    { name: "Coffee", price: 69, description: "Rich ground coffee beans steamed with hot milk." },
    { name: "Black Coffee", price: 49, description: "Intense, natural flavor and aroma, served hot and black." },
    { name: "Mojito (Watermelon / Pineapple / Orange)", price: 129, description: "Fresh mint, lime wedges, fruit crush and club soda.", isPopular: true },
    { name: "Blue Lagoon", price: 129, description: "Vibrant blue curacao mixed with sweet lemonade, topped with sparkling soda." },
    { name: "Kiwi Delight", price: 129, description: "Kiwi crush, sugar syrup, lime juice, soda and sprite." },
    { name: "Chocolate Shake", price: 139, description: "Blended milk, premium cocoa, and rich vanilla ice cream." },
    { name: "Pan Delight", price: 139, description: "Refreshing betel leaf pan flavor with mint and sprite." },
    { name: "Blossom (Mango / Orange / Pineapple)", price: 149, description: "Velvety fruit crush blended with vanilla ice cream and fresh milk." },
    { name: "Fruit Punch", price: 139, description: "Mixed fruit crushes topped with ice cream and creamy milk." },
    { name: "Badam Thandai", price: 149, description: "Almond badam syrup, milk, saffron and cardamoms, with vanilla ice cream." },
    { name: "Mango Smoothie", price: 169, description: "Sweet mango pulp, ice cream, fresh milk and yogurt." },
    { name: "Oreo Smoothie", price: 169, description: "Crunchy Oreo biscuits blended with chocolate fudge, vanilla ice cream, and milk." },
    { name: "Shakes (Vanilla / Butterscotch / Strawberry)", price: 169, description: "Classic whipped ice cream milk shake in your choice of flavor." },
    { name: "Cold Coffee", price: 149, description: "Chilled coffee and sweet milk blended with vanilla ice cream." },
    { name: "Masala Cold Drinks", price: 49, description: "Chilled soda with tangy black salt, cumin, and lime juice." },
    { name: "Butter Milk (Plain / Masala)", price: 89, description: "Churned spiced yogurt drink with roasted cumin and coriander." },
    { name: "Lassi Sweet & Salt", price: 89, description: "Thick creamy sweet or salted traditional Punjabi yogurt shake." },
    { name: "Lassi Triple Fruits", price: 119, description: "Three distinct fruit flavors blended with fresh yogurt." },
    { name: "Fresh Lime Water (Sweet / Salt)", price: 49, description: "Refreshing drink of freshly squeezed limes in pure water." },
    { name: "Fresh Lime Soda", price: 49, description: "Fizzy club soda with freshly squeezed lime, sweet or salted." },
    { name: "Seasonal Fresh Fruit Juice", price: 139, description: "Watermelon, pineapple, orange, sweet lime or mix." },
    { name: "Seasonal Fresh Fruit Shake", price: 159, description: "Banana, apple, chikoo or custard apple with ice cream." }
  ],
  "Desserts": [
    { name: "Gajar ka Halwa", price: 99, description: "Sweet grated carrots simmered in milk, ghee, and loaded with dry fruits.", isPopular: true },
    { name: "Rasgulla Gulab Jamun", price: 89, description: "Combination of spongy white rasgulla and warm sweet gulab jamuns." },
    { name: "Gulab Jamun with Ice Cream", price: 99, description: "Warm, sweet golden dumplings served with cold vanilla bean ice cream.", isPopular: true },
    { name: "Rasmalai", price: 119, description: "Soft, flattened cottage cheese balls soaked in sweet thickened saffron milk." },
    { name: "Chocolate Walnut Brownie", price: 119, description: "Warm, fudgy chocolate brownie loaded with roasted walnuts." },
    { name: "Sizzling Brownie", price: 139, description: "Warm brownie served on a hot iron plate, topped with vanilla ice cream and hot chocolate fudge.", isPopular: true },
    { name: "Banana Toffee", price: 139, description: "Deep fried crispy banana glazed with caramelized honey-sugar syrup." },
    { name: "Apple Toffee", price: 139, description: "Golden fried sweet apple chunks glazed in caramel toffee sauce." }
  ]
};

export function getFoodEmoji(name: string, category?: string): string {
  const lowerName = name.toLowerCase();

  // Soups
  if (lowerName.includes('minestrone')) return '🍲';
  if (lowerName.includes('manchow')) return '🥣';
  if (lowerName.includes('hot n sour')) return '🥣';
  if (lowerName.includes('lemon coriander')) return '🍋';
  if (lowerName.includes('sweet corn')) return '🌽';
  if (lowerName.includes('wonton')) return '🥟';
  if (lowerName.includes('tomato')) return '🍅';
  if (lowerName.includes('soup')) return '🥣';

  // Starters & Tandoor
  if (lowerName.includes('paneer tikka') || lowerName.includes('paneer pudina') || lowerName.includes('paneer pahadi')) return '🍢';
  if (lowerName.includes('kebab') || lowerName.includes('seekh') || lowerName.includes('kakori')) return '🍢';
  if (lowerName.includes('platter')) return '🍱';
  if (lowerName.includes('tikki')) return '🥔';
  if (lowerName.includes('spring roll') || lowerName.includes('korean roll') || lowerName.includes('khasta')) return '🌯';
  if (lowerName.includes('salad')) return '🥗';

  // Asian Wok / Chinese
  if (lowerName.includes('noodle')) return '🍜';
  if (lowerName.includes('fried rice')) return '🍛';
  if (lowerName.includes('rice & noodles') || lowerName.includes('back to china')) return '🥡';
  if (lowerName.includes('manchurian')) return '🧆';
  if (lowerName.includes('momos')) return '🥟';
  if (lowerName.includes('lovely corn')) return '🌽';
  if (lowerName.includes('chilly dry') || lowerName.includes('chilly baby corn') || lowerName.includes('potato chilly') || lowerName.includes('mushroom chilly') || lowerName.includes('paneer 65')) return '🌶️';

  // Italian & Continental
  if (lowerName.includes('pasta')) return '🍝';
  if (lowerName.includes('pizza')) return '🍕';
  if (lowerName.includes('burger')) return '🍔';
  if (lowerName.includes('french fry') || lowerName.includes('fries') || lowerName.includes('potato finger') || lowerName.includes('vegetable finger') || lowerName.includes('paneer finger')) return '🍟';
  if (lowerName.includes('cheese ball') || lowerName.includes('poppers') || lowerName.includes('nugget')) return '🧀';
  if (lowerName.includes('sizzler') || lowerName.includes('stroganoff') || lowerName.includes('shashlik')) return '🍳';

  // Sandwiches
  if (lowerName.includes('sandwich')) return '🥪';
  if (lowerName.includes('garlic bread')) return '🥖';
  if (lowerName.includes('toast')) return '🥪';

  // Indian Mains
  if (lowerName.includes('paneer butter') || lowerName.includes('paneer kadhai') || lowerName.includes('paneer methi') || lowerName.includes('paneer khurchan') || lowerName.includes('paneer kolhapuri')) return '🥘';
  if (lowerName.includes('biryani') || lowerName.includes('pulao')) return '🍛';
  if (lowerName.includes('subz') || lowerName.includes('mix veg')) return '🥗';
  if (lowerName.includes('dal fry') || lowerName.includes('dal makhni') || lowerName.includes('dal tadka') || lowerName.includes('tadkewali dal')) return '🥣';
  if (lowerName.includes('jeera rice') || lowerName.includes('steam rice')) return '🍚';

  // South Indian
  if (lowerName.includes('idli')) return '🍘';
  if (lowerName.includes('dosa')) return '🥞';
  if (lowerName.includes('upma') || lowerName.includes('wada')) return '🍩';
  if (lowerName.includes('poori') || lowerName.includes('chole bhature')) return '🫓';

  // Indian Breads
  if (lowerName.includes('roti') || lowerName.includes('paratha') || lowerName.includes('naan') || lowerName.includes('kulcha')) return '🫓';

  // Beverages & Mocktails
  if (lowerName.includes('jaljeera')) return '🥤';
  if (lowerName.includes('tea') || lowerName.includes('chai')) return '☕';
  if (lowerName.includes('coffee')) return '☕';
  if (lowerName.includes('mojito') || lowerName.includes('lagoon') || lowerName.includes('delight') || lowerName.includes('punch') || lowerName.includes('juice') || lowerName.includes('soda') || lowerName.includes('lime water') || lowerName.includes('cold drink')) return '🍹';
  if (lowerName.includes('shake') || lowerName.includes('smoothie') || lowerName.includes('lassi') || lowerName.includes('milk')) return '🥛';
  if (lowerName.includes('water bottle') || lowerName.includes('water')) return '💧';

  // Desserts
  if (lowerName.includes('halwa')) return '🍯';
  if (lowerName.includes('jamun') || lowerName.includes('rasgulla') || lowerName.includes('rasmalai')) return '🍨';
  if (lowerName.includes('brownie')) return '🍰';
  if (lowerName.includes('toffee')) return '🍬';

  // Category based defaults
  if (category) {
    const cat = category.toLowerCase();
    if (cat.includes('soup')) return '🥣';
    if (cat.includes('starter') || cat.includes('tandoor')) return '🍢';
    if (cat.includes('asian')) return '🍜';
    if (cat.includes('italian')) return '🍝';
    if (cat.includes('pizza') || cat.includes('burger')) return '🍕';
    if (cat.includes('sandwich')) return '🥪';
    if (cat.includes('indian mains')) return '🥘';
    if (cat.includes('south indian')) return '🫓';
    if (cat.includes('bread')) return '🫓';
    if (cat.includes('beverag') || cat.includes('mocktail')) return '🍹';
    if (cat.includes('dessert')) return '🍨';
  }

  return '🥗';
}

