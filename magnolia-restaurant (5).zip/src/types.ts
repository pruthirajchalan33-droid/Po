export interface MenuItem {
  name: string;
  price: number;
  description: string;
  isPopular?: boolean;
}

export interface MenuData {
  [category: string]: MenuItem[];
}

export interface CartItem extends MenuItem {
  category: string;
  quantity: number;
}

export interface ReservationDetails {
  name: string;
  phone: string;
  date: string;
  time: string;
  guests: string;
  notes?: string;
}
